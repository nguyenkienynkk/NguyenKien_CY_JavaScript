Sử dụng JS, WEB API và CSS. Hãy viết một giao diện kéo thả để upload file như video sau 
