Sử dụng JS, WEB API và CSS. Hãy viết một chương trình list note như video sau. Yêu cầu dữ liệu lưu trữ trong localStorage.

